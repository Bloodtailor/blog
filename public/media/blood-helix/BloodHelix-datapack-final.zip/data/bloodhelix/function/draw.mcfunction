# Blood Helix - dispatch
execute if score #t bh.t matches 0..9 run function bloodhelix:draw0
execute if score #t bh.t matches 10..19 run function bloodhelix:draw1
execute if score #t bh.t matches 20..29 run function bloodhelix:draw2
execute if score #t bh.t matches 30..39 run function bloodhelix:draw3
execute if score #t bh.t matches 40..49 run function bloodhelix:draw4
execute if score #t bh.t matches 50..59 run function bloodhelix:draw5
execute if score #t bh.t matches 60..69 run function bloodhelix:draw6
execute if score #t bh.t matches 70..79 run function bloodhelix:draw7
execute if score #t bh.t matches 80..89 run function bloodhelix:draw8
execute if score #t bh.t matches 90..99 run function bloodhelix:draw9
