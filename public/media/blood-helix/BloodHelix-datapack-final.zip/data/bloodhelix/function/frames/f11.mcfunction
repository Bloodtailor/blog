# Blood Helix - tick 11/100
execute rotated 191.0 0 positioned ^0 ^0.29 ^0.83 run particle minecraft:dust{color:[0.9,0.06,0.06],scale:0.9} ~ ~ ~ 0.09 0.05 0.09 0 3 force @a
execute rotated 205.0 0 positioned ^0 ^0.29 ^0.83 run particle minecraft:dust{color:[0.9,0.06,0.06],scale:0.9} ~ ~ ~ 0.09 0.05 0.09 0 3 force @a
execute rotated 198.0 0 positioned ^0 ^0.29 ^0.83 run particle minecraft:dust{color:[0.9,0.06,0.06],scale:0.9} ~ ~ ~ 0 1 0 0.03 0 force @a
execute rotated 11.0 0 positioned ^0 ^0.29 ^0.83 run particle minecraft:dust{color:[0.55,0.0,0.02],scale:0.9} ~ ~ ~ 0.09 0.05 0.09 0 3 force @a
execute rotated 25.0 0 positioned ^0 ^0.29 ^0.83 run particle minecraft:dust{color:[0.55,0.0,0.02],scale:0.9} ~ ~ ~ 0.09 0.05 0.09 0 3 force @a
execute rotated 18.0 0 positioned ^0 ^0.29 ^0.83 run particle minecraft:dust{color:[0.9,0.06,0.06],scale:0.9} ~ ~ ~ 0 1 0 0.03 0 force @a
