# Blood Helix - tick 3/100
execute rotated 47.0 0 positioned ^0 ^0.07 ^0.85 run particle minecraft:dust{color:[0.9,0.06,0.06],scale:0.9} ~ ~ ~ 0.09 0.05 0.09 0 3 force @a
execute rotated 61.0 0 positioned ^0 ^0.07 ^0.85 run particle minecraft:dust{color:[0.9,0.06,0.06],scale:0.9} ~ ~ ~ 0.09 0.05 0.09 0 3 force @a
execute rotated 54.0 0 positioned ^0 ^0.07 ^0.85 run particle minecraft:dust{color:[0.9,0.06,0.06],scale:0.9} ~ ~ ~ 0 1 0 0.03 0 force @a
execute rotated 227.0 0 positioned ^0 ^0.07 ^0.85 run particle minecraft:dust{color:[0.55,0.0,0.02],scale:0.9} ~ ~ ~ 0.09 0.05 0.09 0 3 force @a
execute rotated 241.0 0 positioned ^0 ^0.07 ^0.85 run particle minecraft:dust{color:[0.55,0.0,0.02],scale:0.9} ~ ~ ~ 0.09 0.05 0.09 0 3 force @a
execute rotated 234.0 0 positioned ^0 ^0.07 ^0.85 run particle minecraft:dust{color:[0.9,0.06,0.06],scale:0.9} ~ ~ ~ 0 1 0 0.03 0 force @a
