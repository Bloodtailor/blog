# Blood Helix - tick 42/100
execute rotated 29.0 0 positioned ^0 ^2.02 ^0.71 run particle minecraft:dust{color:[0.9,0.06,0.06],scale:0.9} ~ ~ ~ 0.09 0.05 0.09 0 3 force @a
execute rotated 43.0 0 positioned ^0 ^2.02 ^0.71 run particle minecraft:dust{color:[0.9,0.06,0.06],scale:0.9} ~ ~ ~ 0.09 0.05 0.09 0 3 force @a
execute rotated 36.0 0 positioned ^0 ^2.02 ^0.71 run particle minecraft:dust{color:[0.9,0.06,0.06],scale:0.9} ~ ~ ~ 0 1 0 0.03 0 force @a
execute rotated 209.0 0 positioned ^0 ^2.02 ^0.71 run particle minecraft:dust{color:[0.55,0.0,0.02],scale:0.9} ~ ~ ~ 0.09 0.05 0.09 0 3 force @a
execute rotated 223.0 0 positioned ^0 ^2.02 ^0.71 run particle minecraft:dust{color:[0.55,0.0,0.02],scale:0.9} ~ ~ ~ 0.09 0.05 0.09 0 3 force @a
execute rotated 216.0 0 positioned ^0 ^2.02 ^0.71 run particle minecraft:dust{color:[0.9,0.06,0.06],scale:0.9} ~ ~ ~ 0 1 0 0.03 0 force @a
