# Blood Helix - tick 56/100
execute rotated 281.0 0 positioned ^0 ^2.08 ^0.71 run particle minecraft:dust{color:[0.9,0.06,0.06],scale:0.9} ~ ~ ~ 0.09 0.05 0.09 0 3 force @a
execute rotated 295.0 0 positioned ^0 ^2.08 ^0.71 run particle minecraft:dust{color:[0.9,0.06,0.06],scale:0.9} ~ ~ ~ 0.09 0.05 0.09 0 3 force @a
execute rotated 288.0 0 positioned ^0 ^2.08 ^0.71 run particle minecraft:dust{color:[0.9,0.06,0.06],scale:0.9} ~ ~ ~ 0 1 0 0.03 0 force @a
execute rotated 101.0 0 positioned ^0 ^2.08 ^0.71 run particle minecraft:dust{color:[0.55,0.0,0.02],scale:0.9} ~ ~ ~ 0.09 0.05 0.09 0 3 force @a
execute rotated 115.0 0 positioned ^0 ^2.08 ^0.71 run particle minecraft:dust{color:[0.55,0.0,0.02],scale:0.9} ~ ~ ~ 0.09 0.05 0.09 0 3 force @a
execute rotated 108.0 0 positioned ^0 ^2.08 ^0.71 run particle minecraft:dust{color:[0.9,0.06,0.06],scale:0.9} ~ ~ ~ 0 1 0 0.03 0 force @a
