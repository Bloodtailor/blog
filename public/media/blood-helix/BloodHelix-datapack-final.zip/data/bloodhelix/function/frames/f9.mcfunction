# Blood Helix - tick 9/100
execute rotated 155.0 0 positioned ^0 ^0.21 ^0.84 run particle minecraft:dust{color:[0.9,0.06,0.06],scale:0.9} ~ ~ ~ 0.09 0.05 0.09 0 3 force @a
execute rotated 169.0 0 positioned ^0 ^0.21 ^0.84 run particle minecraft:dust{color:[0.9,0.06,0.06],scale:0.9} ~ ~ ~ 0.09 0.05 0.09 0 3 force @a
execute rotated 162.0 0 positioned ^0 ^0.21 ^0.84 run particle minecraft:dust{color:[0.9,0.06,0.06],scale:0.9} ~ ~ ~ 0 1 0 0.03 0 force @a
execute rotated 335.0 0 positioned ^0 ^0.21 ^0.84 run particle minecraft:dust{color:[0.55,0.0,0.02],scale:0.9} ~ ~ ~ 0.09 0.05 0.09 0 3 force @a
execute rotated 349.0 0 positioned ^0 ^0.21 ^0.84 run particle minecraft:dust{color:[0.55,0.0,0.02],scale:0.9} ~ ~ ~ 0.09 0.05 0.09 0 3 force @a
execute rotated 342.0 0 positioned ^0 ^0.21 ^0.84 run particle minecraft:dust{color:[0.9,0.06,0.06],scale:0.9} ~ ~ ~ 0 1 0 0.03 0 force @a
