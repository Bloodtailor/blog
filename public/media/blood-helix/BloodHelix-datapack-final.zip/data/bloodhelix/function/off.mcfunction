scoreboard players set @s bh.on 0
tellraw @s "[Blood Helix] OFF"
