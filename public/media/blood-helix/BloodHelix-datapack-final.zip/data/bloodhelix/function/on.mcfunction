scoreboard players set @s bh.on 1
tellraw @s "[Blood Helix] ON"
