# Blood Helix - per tick
scoreboard players add #t bh.t 1
scoreboard players operation #t bh.t %= #mod bh.t
execute as @a unless score @s bh.on matches 0..1 run scoreboard players set @s bh.on 1
execute as @a[scores={bloodhelix=1..}] run function bloodhelix:toggle
scoreboard players enable @a bloodhelix
execute as @a[scores={bh.on=1},gamemode=!spectator] at @s run function bloodhelix:draw
