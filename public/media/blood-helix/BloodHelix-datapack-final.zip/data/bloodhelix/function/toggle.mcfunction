# Blood Helix - handle /trigger bloodhelix
scoreboard players set @s bloodhelix 0
scoreboard players set @s bh.tmp 0
execute if score @s bh.on matches 1 run scoreboard players set @s bh.tmp 1
execute if score @s bh.tmp matches 1 run function bloodhelix:off
execute if score @s bh.tmp matches 0 run function bloodhelix:on
scoreboard players enable @s bloodhelix
