# Blood Helix - tick 0 of 24
execute rotated 0.0 0 positioned ^0 ^0.05 ^0.30 run particle minecraft:dust{color:[0.32,0.0,0.02],scale:0.6} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 180.0 0 positioned ^0 ^0.05 ^0.30 run particle minecraft:dust{color:[0.32,0.0,0.02],scale:0.6} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 0.0 0 positioned ^0 ^1.18 ^0.63 run particle minecraft:dust{color:[0.652,0.037,0.063],scale:0.53} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 180.0 0 positioned ^0 ^1.18 ^0.63 run particle minecraft:dust{color:[0.652,0.037,0.063],scale:0.53} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 10.0 0 positioned ^0 ^0.08 ^0.32 run particle minecraft:dust{color:[0.347,0.003,0.024],scale:0.6} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 190.0 0 positioned ^0 ^0.08 ^0.32 run particle minecraft:dust{color:[0.347,0.003,0.024],scale:0.6} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 10.0 0 positioned ^0 ^1.21 ^0.64 run particle minecraft:dust{color:[0.659,0.038,0.064],scale:0.53} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 190.0 0 positioned ^0 ^1.21 ^0.64 run particle minecraft:dust{color:[0.659,0.038,0.064],scale:0.53} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 20.0 0 positioned ^0 ^0.11 ^0.33 run particle minecraft:dust{color:[0.364,0.005,0.026],scale:0.6} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 200.0 0 positioned ^0 ^0.11 ^0.33 run particle minecraft:dust{color:[0.364,0.005,0.026],scale:0.6} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 20.0 0 positioned ^0 ^1.24 ^0.65 run particle minecraft:dust{color:[0.665,0.038,0.065],scale:0.53} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 200.0 0 positioned ^0 ^1.24 ^0.65 run particle minecraft:dust{color:[0.665,0.038,0.065],scale:0.53} ~ ~ ~ 0 0 0 0 1 force @a
