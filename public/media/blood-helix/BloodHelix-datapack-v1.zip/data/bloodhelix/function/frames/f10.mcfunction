# Blood Helix - tick 10 of 24
execute rotated 300.0 0 positioned ^0 ^0.99 ^0.59 run particle minecraft:dust{color:[0.613,0.033,0.058],scale:0.54} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 120.0 0 positioned ^0 ^0.99 ^0.59 run particle minecraft:dust{color:[0.613,0.033,0.058],scale:0.54} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 300.0 0 positioned ^0 ^2.11 ^0.84 run particle minecraft:dust{color:[0.828,0.056,0.086],scale:0.47} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 120.0 0 positioned ^0 ^2.11 ^0.84 run particle minecraft:dust{color:[0.828,0.056,0.086],scale:0.47} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 310.0 0 positioned ^0 ^1.02 ^0.60 run particle minecraft:dust{color:[0.619,0.033,0.059],scale:0.54} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 130.0 0 positioned ^0 ^1.02 ^0.60 run particle minecraft:dust{color:[0.619,0.033,0.059],scale:0.54} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 310.0 0 positioned ^0 ^2.14 ^0.85 run particle minecraft:dust{color:[0.833,0.057,0.087],scale:0.47} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 130.0 0 positioned ^0 ^2.14 ^0.85 run particle minecraft:dust{color:[0.833,0.057,0.087],scale:0.47} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 320.0 0 positioned ^0 ^1.05 ^0.60 run particle minecraft:dust{color:[0.626,0.034,0.06],scale:0.54} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 140.0 0 positioned ^0 ^1.05 ^0.60 run particle minecraft:dust{color:[0.626,0.034,0.06],scale:0.54} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 320.0 0 positioned ^0 ^2.17 ^0.85 run particle minecraft:dust{color:[0.839,0.058,0.087],scale:0.47} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 140.0 0 positioned ^0 ^2.17 ^0.85 run particle minecraft:dust{color:[0.839,0.058,0.087],scale:0.47} ~ ~ ~ 0 0 0 0 1 force @a
