# Blood Helix - tick 11 of 24
execute rotated 330.0 0 positioned ^0 ^1.08 ^0.61 run particle minecraft:dust{color:[0.633,0.035,0.061],scale:0.54} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 150.0 0 positioned ^0 ^1.08 ^0.61 run particle minecraft:dust{color:[0.633,0.035,0.061],scale:0.54} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 330.0 0 positioned ^0 ^2.21 ^0.86 run particle minecraft:dust{color:[0.844,0.058,0.088],scale:0.47} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 150.0 0 positioned ^0 ^2.21 ^0.86 run particle minecraft:dust{color:[0.844,0.058,0.088],scale:0.47} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 340.0 0 positioned ^0 ^1.11 ^0.62 run particle minecraft:dust{color:[0.639,0.035,0.061],scale:0.53} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 160.0 0 positioned ^0 ^1.11 ^0.62 run particle minecraft:dust{color:[0.639,0.035,0.061],scale:0.53} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 340.0 0 positioned ^0 ^2.24 ^0.87 run particle minecraft:dust{color:[0.849,0.059,0.089],scale:0.46} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 160.0 0 positioned ^0 ^2.24 ^0.87 run particle minecraft:dust{color:[0.849,0.059,0.089],scale:0.46} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 350.0 0 positioned ^0 ^1.14 ^0.63 run particle minecraft:dust{color:[0.646,0.036,0.062],scale:0.53} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 170.0 0 positioned ^0 ^1.14 ^0.63 run particle minecraft:dust{color:[0.646,0.036,0.062],scale:0.53} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 350.0 0 positioned ^0 ^2.27 ^0.87 run particle minecraft:dust{color:[0.855,0.059,0.089],scale:0.46} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 170.0 0 positioned ^0 ^2.27 ^0.87 run particle minecraft:dust{color:[0.855,0.059,0.089],scale:0.46} ~ ~ ~ 0 0 0 0 1 force @a
