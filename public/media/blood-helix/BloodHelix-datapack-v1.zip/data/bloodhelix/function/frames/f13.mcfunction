# Blood Helix - tick 13 of 24
execute rotated 30.0 0 positioned ^0 ^1.27 ^0.66 run particle minecraft:dust{color:[0.672,0.039,0.066],scale:0.52} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 210.0 0 positioned ^0 ^1.27 ^0.66 run particle minecraft:dust{color:[0.672,0.039,0.066],scale:0.52} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 30.0 0 positioned ^0 ^0.14 ^0.35 run particle minecraft:dust{color:[0.378,0.006,0.028],scale:0.59} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 210.0 0 positioned ^0 ^0.14 ^0.35 run particle minecraft:dust{color:[0.378,0.006,0.028],scale:0.59} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 40.0 0 positioned ^0 ^1.30 ^0.66 run particle minecraft:dust{color:[0.678,0.04,0.066],scale:0.52} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 220.0 0 positioned ^0 ^1.30 ^0.66 run particle minecraft:dust{color:[0.678,0.04,0.066],scale:0.52} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 40.0 0 positioned ^0 ^0.18 ^0.36 run particle minecraft:dust{color:[0.391,0.008,0.029],scale:0.59} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 220.0 0 positioned ^0 ^0.18 ^0.36 run particle minecraft:dust{color:[0.391,0.008,0.029],scale:0.59} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 50.0 0 positioned ^0 ^1.33 ^0.67 run particle minecraft:dust{color:[0.684,0.04,0.067],scale:0.52} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 230.0 0 positioned ^0 ^1.33 ^0.67 run particle minecraft:dust{color:[0.684,0.04,0.067],scale:0.52} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 50.0 0 positioned ^0 ^0.21 ^0.37 run particle minecraft:dust{color:[0.403,0.009,0.031],scale:0.59} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 230.0 0 positioned ^0 ^0.21 ^0.37 run particle minecraft:dust{color:[0.403,0.009,0.031],scale:0.59} ~ ~ ~ 0 0 0 0 1 force @a
