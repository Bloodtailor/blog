# Blood Helix - tick 16 of 24
execute rotated 120.0 0 positioned ^0 ^1.55 ^0.72 run particle minecraft:dust{color:[0.727,0.045,0.073],scale:0.51} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 300.0 0 positioned ^0 ^1.55 ^0.72 run particle minecraft:dust{color:[0.727,0.045,0.073],scale:0.51} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 120.0 0 positioned ^0 ^0.42 ^0.44 run particle minecraft:dust{color:[0.474,0.017,0.04],scale:0.58} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 300.0 0 positioned ^0 ^0.42 ^0.44 run particle minecraft:dust{color:[0.474,0.017,0.04],scale:0.58} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 130.0 0 positioned ^0 ^1.58 ^0.73 run particle minecraft:dust{color:[0.732,0.046,0.073],scale:0.5} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 310.0 0 positioned ^0 ^1.58 ^0.73 run particle minecraft:dust{color:[0.732,0.046,0.073],scale:0.5} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 130.0 0 positioned ^0 ^0.46 ^0.45 run particle minecraft:dust{color:[0.483,0.018,0.041],scale:0.57} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 310.0 0 positioned ^0 ^0.46 ^0.45 run particle minecraft:dust{color:[0.483,0.018,0.041],scale:0.57} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 140.0 0 positioned ^0 ^1.61 ^0.73 run particle minecraft:dust{color:[0.738,0.046,0.074],scale:0.5} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 320.0 0 positioned ^0 ^1.61 ^0.73 run particle minecraft:dust{color:[0.738,0.046,0.074],scale:0.5} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 140.0 0 positioned ^0 ^0.49 ^0.46 run particle minecraft:dust{color:[0.492,0.019,0.042],scale:0.57} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 320.0 0 positioned ^0 ^0.49 ^0.46 run particle minecraft:dust{color:[0.492,0.019,0.042],scale:0.57} ~ ~ ~ 0 0 0 0 1 force @a
