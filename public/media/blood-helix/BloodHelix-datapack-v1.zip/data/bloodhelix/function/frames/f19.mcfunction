# Blood Helix - tick 19 of 24
execute rotated 210.0 0 positioned ^0 ^1.83 ^0.78 run particle minecraft:dust{color:[0.779,0.051,0.079],scale:0.49} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 30.0 0 positioned ^0 ^1.83 ^0.78 run particle minecraft:dust{color:[0.779,0.051,0.079],scale:0.49} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 210.0 0 positioned ^0 ^0.71 ^0.52 run particle minecraft:dust{color:[0.548,0.025,0.05],scale:0.56} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 30.0 0 positioned ^0 ^0.71 ^0.52 run particle minecraft:dust{color:[0.548,0.025,0.05],scale:0.56} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 220.0 0 positioned ^0 ^1.86 ^0.79 run particle minecraft:dust{color:[0.784,0.052,0.08],scale:0.49} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 40.0 0 positioned ^0 ^1.86 ^0.79 run particle minecraft:dust{color:[0.784,0.052,0.08],scale:0.49} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 220.0 0 positioned ^0 ^0.74 ^0.52 run particle minecraft:dust{color:[0.555,0.026,0.051],scale:0.56} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 40.0 0 positioned ^0 ^0.74 ^0.52 run particle minecraft:dust{color:[0.555,0.026,0.051],scale:0.56} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 230.0 0 positioned ^0 ^1.89 ^0.79 run particle minecraft:dust{color:[0.79,0.052,0.081],scale:0.49} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 50.0 0 positioned ^0 ^1.89 ^0.79 run particle minecraft:dust{color:[0.79,0.052,0.081],scale:0.49} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 230.0 0 positioned ^0 ^0.77 ^0.53 run particle minecraft:dust{color:[0.563,0.027,0.051],scale:0.56} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 50.0 0 positioned ^0 ^0.77 ^0.53 run particle minecraft:dust{color:[0.563,0.027,0.051],scale:0.56} ~ ~ ~ 0 0 0 0 1 force @a
