# Blood Helix - tick 2 of 24
execute rotated 60.0 0 positioned ^0 ^0.24 ^0.38 run particle minecraft:dust{color:[0.415,0.011,0.032],scale:0.59} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 240.0 0 positioned ^0 ^0.24 ^0.38 run particle minecraft:dust{color:[0.415,0.011,0.032],scale:0.59} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 60.0 0 positioned ^0 ^1.36 ^0.68 run particle minecraft:dust{color:[0.69,0.041,0.068],scale:0.52} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 240.0 0 positioned ^0 ^1.36 ^0.68 run particle minecraft:dust{color:[0.69,0.041,0.068],scale:0.52} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 70.0 0 positioned ^0 ^0.27 ^0.39 run particle minecraft:dust{color:[0.426,0.012,0.034],scale:0.59} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 250.0 0 positioned ^0 ^0.27 ^0.39 run particle minecraft:dust{color:[0.426,0.012,0.034],scale:0.59} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 70.0 0 positioned ^0 ^1.39 ^0.68 run particle minecraft:dust{color:[0.696,0.042,0.069],scale:0.52} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 250.0 0 positioned ^0 ^1.39 ^0.68 run particle minecraft:dust{color:[0.696,0.042,0.069],scale:0.52} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 80.0 0 positioned ^0 ^0.30 ^0.40 run particle minecraft:dust{color:[0.436,0.013,0.035],scale:0.58} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 260.0 0 positioned ^0 ^0.30 ^0.40 run particle minecraft:dust{color:[0.436,0.013,0.035],scale:0.58} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 80.0 0 positioned ^0 ^1.43 ^0.69 run particle minecraft:dust{color:[0.703,0.043,0.07],scale:0.51} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 260.0 0 positioned ^0 ^1.43 ^0.69 run particle minecraft:dust{color:[0.703,0.043,0.07],scale:0.51} ~ ~ ~ 0 0 0 0 1 force @a
