# Blood Helix - tick 21 of 24
execute rotated 270.0 0 positioned ^0 ^2.02 ^0.82 run particle minecraft:dust{color:[0.812,0.055,0.084],scale:0.48} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 90.0 0 positioned ^0 ^2.02 ^0.82 run particle minecraft:dust{color:[0.812,0.055,0.084],scale:0.48} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 270.0 0 positioned ^0 ^0.89 ^0.56 run particle minecraft:dust{color:[0.592,0.03,0.055],scale:0.55} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 90.0 0 positioned ^0 ^0.89 ^0.56 run particle minecraft:dust{color:[0.592,0.03,0.055],scale:0.55} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 280.0 0 positioned ^0 ^2.05 ^0.83 run particle minecraft:dust{color:[0.817,0.055,0.084],scale:0.48} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 100.0 0 positioned ^0 ^2.05 ^0.83 run particle minecraft:dust{color:[0.817,0.055,0.084],scale:0.48} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 280.0 0 positioned ^0 ^0.92 ^0.57 run particle minecraft:dust{color:[0.599,0.031,0.056],scale:0.55} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 100.0 0 positioned ^0 ^0.92 ^0.57 run particle minecraft:dust{color:[0.599,0.031,0.056],scale:0.55} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 290.0 0 positioned ^0 ^2.08 ^0.83 run particle minecraft:dust{color:[0.823,0.056,0.085],scale:0.47} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 110.0 0 positioned ^0 ^2.08 ^0.83 run particle minecraft:dust{color:[0.823,0.056,0.085],scale:0.47} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 290.0 0 positioned ^0 ^0.96 ^0.58 run particle minecraft:dust{color:[0.606,0.032,0.057],scale:0.54} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 110.0 0 positioned ^0 ^0.96 ^0.58 run particle minecraft:dust{color:[0.606,0.032,0.057],scale:0.54} ~ ~ ~ 0 0 0 0 1 force @a
