# Blood Helix - tick 3 of 24
execute rotated 90.0 0 positioned ^0 ^0.33 ^0.41 run particle minecraft:dust{color:[0.446,0.014,0.036],scale:0.58} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 270.0 0 positioned ^0 ^0.33 ^0.41 run particle minecraft:dust{color:[0.446,0.014,0.036],scale:0.58} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 90.0 0 positioned ^0 ^1.46 ^0.70 run particle minecraft:dust{color:[0.709,0.043,0.07],scale:0.51} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 270.0 0 positioned ^0 ^1.46 ^0.70 run particle minecraft:dust{color:[0.709,0.043,0.07],scale:0.51} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 100.0 0 positioned ^0 ^0.36 ^0.42 run particle minecraft:dust{color:[0.456,0.015,0.038],scale:0.58} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 280.0 0 positioned ^0 ^0.36 ^0.42 run particle minecraft:dust{color:[0.456,0.015,0.038],scale:0.58} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 100.0 0 positioned ^0 ^1.49 ^0.71 run particle minecraft:dust{color:[0.715,0.044,0.071],scale:0.51} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 280.0 0 positioned ^0 ^1.49 ^0.71 run particle minecraft:dust{color:[0.715,0.044,0.071],scale:0.51} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 110.0 0 positioned ^0 ^0.39 ^0.43 run particle minecraft:dust{color:[0.465,0.016,0.039],scale:0.58} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 290.0 0 positioned ^0 ^0.39 ^0.43 run particle minecraft:dust{color:[0.465,0.016,0.039],scale:0.58} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 110.0 0 positioned ^0 ^1.52 ^0.71 run particle minecraft:dust{color:[0.721,0.045,0.072],scale:0.51} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 290.0 0 positioned ^0 ^1.52 ^0.71 run particle minecraft:dust{color:[0.721,0.045,0.072],scale:0.51} ~ ~ ~ 0 0 0 0 1 force @a
