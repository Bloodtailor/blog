# Blood Helix - tick 5 of 24
execute rotated 150.0 0 positioned ^0 ^0.52 ^0.47 run particle minecraft:dust{color:[0.5,0.02,0.043],scale:0.57} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 330.0 0 positioned ^0 ^0.52 ^0.47 run particle minecraft:dust{color:[0.5,0.02,0.043],scale:0.57} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 150.0 0 positioned ^0 ^1.64 ^0.74 run particle minecraft:dust{color:[0.744,0.047,0.075],scale:0.5} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 330.0 0 positioned ^0 ^1.64 ^0.74 run particle minecraft:dust{color:[0.744,0.047,0.075],scale:0.5} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 160.0 0 positioned ^0 ^0.55 ^0.47 run particle minecraft:dust{color:[0.508,0.021,0.044],scale:0.57} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 340.0 0 positioned ^0 ^0.55 ^0.47 run particle minecraft:dust{color:[0.508,0.021,0.044],scale:0.57} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 160.0 0 positioned ^0 ^1.68 ^0.75 run particle minecraft:dust{color:[0.75,0.048,0.076],scale:0.5} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 340.0 0 positioned ^0 ^1.68 ^0.75 run particle minecraft:dust{color:[0.75,0.048,0.076],scale:0.5} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 170.0 0 positioned ^0 ^0.58 ^0.48 run particle minecraft:dust{color:[0.517,0.022,0.045],scale:0.57} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 350.0 0 positioned ^0 ^0.58 ^0.48 run particle minecraft:dust{color:[0.517,0.022,0.045],scale:0.57} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 170.0 0 positioned ^0 ^1.71 ^0.75 run particle minecraft:dust{color:[0.756,0.048,0.076],scale:0.5} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 350.0 0 positioned ^0 ^1.71 ^0.75 run particle minecraft:dust{color:[0.756,0.048,0.076],scale:0.5} ~ ~ ~ 0 0 0 0 1 force @a
