# Blood Helix - tick 6 of 24
execute rotated 180.0 0 positioned ^0 ^0.61 ^0.49 run particle minecraft:dust{color:[0.525,0.023,0.047],scale:0.56} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 0.0 0 positioned ^0 ^0.61 ^0.49 run particle minecraft:dust{color:[0.525,0.023,0.047],scale:0.56} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 180.0 0 positioned ^0 ^1.74 ^0.76 run particle minecraft:dust{color:[0.762,0.049,0.077],scale:0.49} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 0.0 0 positioned ^0 ^1.74 ^0.76 run particle minecraft:dust{color:[0.762,0.049,0.077],scale:0.49} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 190.0 0 positioned ^0 ^0.64 ^0.50 run particle minecraft:dust{color:[0.533,0.024,0.048],scale:0.56} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 10.0 0 positioned ^0 ^0.64 ^0.50 run particle minecraft:dust{color:[0.533,0.024,0.048],scale:0.56} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 190.0 0 positioned ^0 ^1.77 ^0.77 run particle minecraft:dust{color:[0.767,0.05,0.078],scale:0.49} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 10.0 0 positioned ^0 ^1.77 ^0.77 run particle minecraft:dust{color:[0.767,0.05,0.078],scale:0.49} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 200.0 0 positioned ^0 ^0.68 ^0.51 run particle minecraft:dust{color:[0.54,0.024,0.049],scale:0.56} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 20.0 0 positioned ^0 ^0.68 ^0.51 run particle minecraft:dust{color:[0.54,0.024,0.049],scale:0.56} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 200.0 0 positioned ^0 ^1.80 ^0.77 run particle minecraft:dust{color:[0.773,0.05,0.079],scale:0.49} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 20.0 0 positioned ^0 ^1.80 ^0.77 run particle minecraft:dust{color:[0.773,0.05,0.079],scale:0.49} ~ ~ ~ 0 0 0 0 1 force @a
