# Blood Helix - tick 8 of 24
execute rotated 240.0 0 positioned ^0 ^0.80 ^0.54 run particle minecraft:dust{color:[0.57,0.028,0.052],scale:0.55} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 60.0 0 positioned ^0 ^0.80 ^0.54 run particle minecraft:dust{color:[0.57,0.028,0.052],scale:0.55} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 240.0 0 positioned ^0 ^1.92 ^0.80 run particle minecraft:dust{color:[0.795,0.053,0.082],scale:0.48} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 60.0 0 positioned ^0 ^1.92 ^0.80 run particle minecraft:dust{color:[0.795,0.053,0.082],scale:0.48} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 250.0 0 positioned ^0 ^0.83 ^0.55 run particle minecraft:dust{color:[0.578,0.029,0.053],scale:0.55} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 70.0 0 positioned ^0 ^0.83 ^0.55 run particle minecraft:dust{color:[0.578,0.029,0.053],scale:0.55} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 250.0 0 positioned ^0 ^1.96 ^0.81 run particle minecraft:dust{color:[0.801,0.053,0.082],scale:0.48} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 70.0 0 positioned ^0 ^1.96 ^0.81 run particle minecraft:dust{color:[0.801,0.053,0.082],scale:0.48} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 260.0 0 positioned ^0 ^0.86 ^0.56 run particle minecraft:dust{color:[0.585,0.029,0.054],scale:0.55} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 80.0 0 positioned ^0 ^0.86 ^0.56 run particle minecraft:dust{color:[0.585,0.029,0.054],scale:0.55} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 260.0 0 positioned ^0 ^1.99 ^0.81 run particle minecraft:dust{color:[0.806,0.054,0.083],scale:0.48} ~ ~ ~ 0 0 0 0 1 force @a
execute rotated 80.0 0 positioned ^0 ^1.99 ^0.81 run particle minecraft:dust{color:[0.806,0.054,0.083],scale:0.48} ~ ~ ~ 0 0 0 0 1 force @a
