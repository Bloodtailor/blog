# Blood Helix - setup
scoreboard objectives add bh.on dummy
scoreboard objectives add bh.t dummy
scoreboard objectives add bh.tmp dummy
scoreboard objectives add bloodhelix trigger
scoreboard players set #mod bh.t 24
scoreboard players add #t bh.t 0
scoreboard players enable @a bloodhelix
tellraw @a "[Blood Helix] Loaded. Run /trigger bloodhelix to turn it on or off."
